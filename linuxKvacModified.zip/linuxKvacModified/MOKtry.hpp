#pragma once

void setup();
//int main();
uint8_t* runNIZKPKForKVAC(uint8_t n[], uint8_t man_sec[], uint8_t client_key[], int byteCount, uECC_word_t* randomReturn, uECC_Curve curve);
